package tp;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Reset extends Thread{
		
		
		@Override
		public  void run() {
		// TODO Auto-generated method stub
			
		int count = 20;
			
			for(int i = 20; i>=0; i--) {
				
			if(i!=0){
				try {
					
					Thread.sleep(1000);
					System.out.println(i);
								
				} catch (Exception e) {
					// TODO: handle exception
				}
					
						
				}else {
					JOptionPane.showMessageDialog(null, "아무런 동작을 하지 않아 메인화면으로 돌아갑니다.", "안내", JOptionPane.INFORMATION_MESSAGE);
				
				}
		
			}
		}


	
	
//		public void Reset() {
//			// TODO Auto-generated constructor stub
//			
//		
//		PanelChange pch = new PanelChange();
//		
//		Thread th = new Thread();
//		
//		Timer rs = new Timer();
//		
//		TimerTask tt = new TimerTask() {
//			
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				
//				int count = 20;
//				while(true) {
//					
//					
//				 try {
//					th.sleep(1000);
//					
//					MouseListener me = new MouseAdapter() {
//					@Override
//					public void mouseClicked(MouseEvent e) {
//						// TODO Auto-generated method stub
//					
//					}
//					
//					};
//					
//					
//				} catch (Exception e) {
//					// TODO: handle exception
//				}
//					if(count > 0) {
//						
//						count --;
//						
//					}
//
//				
//					else {
//						JOptionPane.showMessageDialog(null, "아무런 동작을 하지 않아 메인화면으로 돌아갑니다.", "안내", JOptionPane.INFORMATION_MESSAGE);
//						//팝업에 20초 카운트 되게 설정
//						
//						//취소누르면 동작정지하고 리셋.
//						
//						//방치하면 0이 되는 순간 메인화면으로 되돌아감.
//						
//						pch.change("fm");
//						
//						
//					}
//			
//			}
//			}
//		
//	};
//	
//	
//		rs.schedule(tt, 20000);
//	
//	
//}		
//		




}

	
	


			
		
		
 


	

