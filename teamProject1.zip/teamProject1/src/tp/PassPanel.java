package tp;

import java.awt.Font;

import tp.FirstMain;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class PassPanel extends JPanel{

	private PanelChange pch;
	
	public PassPanel(PanelChange pch) {
		
		// TODO Auto-generated constructor stub	
	
		this.pch = pch;	
		
		setLayout(null);
		
		

			
		JButton cancle = new JButton("취소 하기");
		JLabel jlb = new JLabel();
		
		cancle.setFont(new Font("취소 하기", Font.BOLD, 11));
		cancle.setFont(jlb.getFont().deriveFont(25.0f));
		cancle.setBounds(10, 10 ,150 ,50);
		cancle.setVisible(true);
		
		cancle.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				pch.change("fm");
				//new FirstMain();
				//setVisible(false);
				
					
			}
		});
		
		
		add(cancle);
		
		
		//시간 지나면 되돌아가는 코드.
		
		//Reset에서 복사 붙여넣기 해오면 편함.
	
//		Thread th = new Thread();
//		
//		Timer rs = new Timer();
//		
//		TimerTask tt = new TimerTask() {
//			
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				
//				int count= 20;
//							
//				
//				for(int i = count; i>=0; i--) {
//					
//					if(i!=0) {
//					try {
//					th.sleep(1000);
//					System.out.println(i);
//
//
//					
//					} catch (Exception e) {
//					// TODO: handle exception
//					}
//				
//					}else {
//						JOptionPane.showMessageDialog(null, "아무런 동작을 하지 않아 메인화면으로 돌아갑니다.", "안내", JOptionPane.INFORMATION_MESSAGE);
//						
//						pch.change("fm");
//						
//						//창을 닫으면 메인화면으로 돌아감.
//					}
//			
//			}
//			}
//		
//	};
	


	
	
		//rs.schedule(tt, 2000);

		
		//rs.schedule(tt, 5000);
		
		//1만 단위 -> 10초 단위.
		
		//시간 지나면 되돌아가는 코드.
		
		//다른 패널에서 작동하지 않게할 방법 필요, 특정 패널에서만 작동하게 할 방법 필요, 마우스 클릭시 시간 연장
	

		
		
		setBounds(150, 150, 500, 700);
		
		setVisible(true);
		
		
	}
}
