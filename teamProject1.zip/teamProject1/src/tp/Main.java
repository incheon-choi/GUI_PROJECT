package tp;

import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;



public class Main {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		PanelChange pch = new PanelChange();
		
		pch.setTitle("분식집 키오스크");
		
		pch.fm = new FirstMain(pch);
		pch.pp = new PassPanel(pch);
		
		
		pch.add(pch.fm);
		
		
		pch.setBounds(150, 150, 500, 700);
		pch.setResizable(false);
		pch.setVisible(true);
		pch.setDefaultCloseOperation(pch.EXIT_ON_CLOSE);
		

		
		

	}

}




/*
 * 구현해야 할 내용 : 
 * 
 *  1.초기 화면띄우기. O
 *  
 *  2.초기 화면에 구현해야 하는버튼은 2개(매장주문/포장주문) O
 *  -> 버튼을 누르면 창을 닫지 않고 패널 전환, 2번 화면에서 취소버튼작동 확인. 
 * 	 
 *  3.메인화면에 무작위 이미지가 순차적으로 돌아가게 구현. △
 *  
 *  ->적당한 이미지 편집해서 gif로 넣기.
 *  ->상호명 추가할 필요 있음.
 *  
 *  
 *  4.입력이 없을 시 자동으로 초기화면으로 돌아갈 클래스 작성 △
 *  ->reset에 작성.
 *  PassPanel에서 대기하고 있을 경우 20~30초? 동안 입력이 없을시 초기화면으로 복귀.
 *  ->마우스 입력 발생시 리셋으로 변경.
 *  
 *  
 *  
 *  5.초기 사이즈는 500/700
 * 
 * 
 */



