package tp;

public class SaveImage {

}
