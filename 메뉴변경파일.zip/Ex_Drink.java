package ex1111;

import java.awt.Color;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Ex_Drink extends JPanel {

	private int count= 0;
	private String show = "";
	private JButton before;
	private JButton pay;
	private Ex_MenuTest mt;
	
	public Ex_Drink(Ex_MenuTest mt) {
		this.mt = mt;
		
		//패널의 총 위치,크기
		setBounds(0,0,500,700);
		
		//패널의 레이아웃
		setLayout(null);
		
		//패널의 배경색
		setBackground(new Color(255,255,215));
		
		
		//패널 배열 설정 부분
		String[] menu = {"코카콜라","코카콜라(제로)","스프라이트","환타(오렌지)","환타(포도)","닥터페퍼"};
		int[] price = {1500,1500,1500,1500,1500,1500};
		JButton[] bt = new JButton[menu.length];
		JLabel[] namel = new JLabel[menu.length];
		JLabel[] pricel = new JLabel[menu.length];
		ImageIcon[] icon = new ImageIcon[menu.length];
		
		for(int i=0; i<menu.length; i++) {
			
			//음료 버튼
			bt[i] = new JButton(menu[i]);
			if(i<3) {
				bt[i].setBounds(37+i*150, 110, 100, 100);
			}else {
				bt[i].setBounds(37+(i-3)*150, 290, 100, 100);
			}
			//음료버튼에 이미지 삽입
			//icon[i] = new ImageIcon(i+"")
			//bt[i].setIcon(icon[i]);
			
			//이름
			namel[i] = new JLabel(menu[i]);
			if(i==0||i==4||i==5) {
				namel[i].setBounds(bt[i].getX()+30, bt[i].getY()+100, 100, 30);
			} else if(i==1){
				namel[i].setBounds(bt[i].getX()+20, bt[i].getY()+100, 100, 30);
			} else if(i==2){
				namel[i].setBounds(bt[i].getX()+22, bt[i].getY()+100, 100, 30);
			} else if(i==3){
				namel[i].setBounds(bt[i].getX()+16, bt[i].getY()+100, 100, 30);
			} 
			
			//가격
			pricel[i] = new JLabel(price[i] + "원");
			if(i<3) {
				pricel[i].setBounds(bt[i].getX()+30, bt[i].getY()+120, 100, 30);
			}else {
				pricel[i].setBounds(bt[i].getX()+30, bt[i].getY()+120, 100, 30);
			}
			
			//패널에 버튼 추가
			add(bt[i]);
			add(namel[i]);
			add(pricel[i]);	
			
		}//for문	
		
		//메뉴주문리스트
		JTextArea ta = new JTextArea(20,20);
		ta.setBounds(0, 450, 500, 150);
		ta.setText("     상품명     단가     수량");
		ta.setBackground(Color.WHITE);
		ta.setEditable(false);
		
		//패널에 메뉴주문리스트 추가
		add(ta);
		
		//버튼 누르면 상품명, 단가, 수량 증가
		for(int i=0; i<menu.length; i++) {
			int j = i;
			
			bt[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					count += 1;
					
					//ta.setText(menu[j]);
					//ta.setText(price[j]);
					ta.setText(count+"");
					
					
				}
			});
		}
		
		//이전,결제버튼 위치,크기 지정
		before = new JButton("이   전");
		pay = new JButton("결   제");
		before.setBounds(100, 610, 100, 40);
		pay.setBounds(300, 610, 100, 40);
		
		//패널에 이전,결제버튼 추가
		add(before);
		add(pay);
		
		//이전버튼 누르면 맨 처음 프레임으로 돌아가는 기능
		before.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				mt.change("before");
			}
		});
		//결제버튼 누르면 결제창으로 넘어가는 기능
		pay.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				mt.change("pay");
			}
		});
	}
}
