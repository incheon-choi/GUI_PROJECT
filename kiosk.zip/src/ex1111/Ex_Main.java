package ex1111;

import ex1111.Ex_Gimbap;
import ex1111.Ex_MenuButton;
import ex1111.Ex_MenuTest;
import ex1111.Ex_Panel01;

public class Ex_Main {
	public static void main(String[] args) {
		Ex_MenuTest mt = new Ex_MenuTest();
		mt.setLayout(null);
		
		mt.setTitle("�н���");
		
		mt.fmPanel = new Ex_FirstMain(mt);
		mt.mbPanel = new Ex_MenuButton(mt);
		mt.gimbapPanel = new Ex_Gimbap(mt);
		mt.noodlePanel = new Ex_Noodle(mt);
		mt.mealPanel = new Ex_Meal(mt);
		mt.drinkPanel = new Ex_Drink(mt);
		mt.basket = new Ex_Panel01(mt);
		
		
		mt.add(mt.fmPanel);
		mt.add(mt.mbPanel);
		mt.add(mt.gimbapPanel);
		mt.add(mt.noodlePanel);
		mt.add(mt.mealPanel);
		mt.add(mt.drinkPanel);
		mt.add(mt.basket);
		
		mt.setBounds(0, 0, 500, 700);
		mt.setVisible(true);
		mt.setDefaultCloseOperation(mt.EXIT_ON_CLOSE);

	}

}
