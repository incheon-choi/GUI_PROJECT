package ex1111;


import javax.swing.JFrame;


import ex1111.*;


public class Ex_Panel01Main extends JFrame {
//	public Ex_FirstMain fmPanel;
//	public Ex_Gimbap gimbapPanel;
//	public Ex_Noodle noodlePanel;
//	public Ex_Meal mealPanel;
//	public Ex_Drink drinkPanel;
//	public Ex_MenuButton mbPanel;
//	public Ex_Panel01 basket;
//	
//	public void change(String panelName) {
//		if(panelName.equals("Jbutton1")) {
//			getContentPane().removeAll();
//			getContentPane().add(gimbapPanel);
//			revalidate();
//			repaint();
//		}else if(panelName.equals("Jbutton2")) {
//			getContentPane().removeAll();
//			getContentPane().add(fmPanel);
//			revalidate();
//			repaint();
//		}	else if(panelName.equals("Jbutton3")) {
//			getContentPane().removeAll();
//			getContentPane().add(fmPanel);
//			revalidate();
//			repaint();
//		}
//	}
//	
	
}