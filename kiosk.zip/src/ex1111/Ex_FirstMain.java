package ex1111;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class Ex_FirstMain extends JPanel {

	private JButton order1;
	private JButton order2;
	private Ex_MenuTest mt;

	public Ex_FirstMain(Ex_MenuTest mt) {
		this.mt = mt;

		setLayout(null);
		setBounds(0, 0, 500, 700);

		order1 = new JButton("���� �ֹ�");
		order2 = new JButton("���� �ֹ�");

		order1.setBounds(60, 490, 150, 90);
		order2.setBounds(280, 490, 150, 90);

		add(order1);
		add(order2);

		// ��ɱ���
		order1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				mt.change("here");

			}
		});

		order2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				mt.change("takeout");
			}
		});
	}
}
