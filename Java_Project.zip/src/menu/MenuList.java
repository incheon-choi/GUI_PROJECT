package menu;

public class MenuList {
	
}
