package cafe;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class CafeFirstMain extends JPanel {

	private JButton order1;
	private JButton order2;
	
	public CafeFirstMain() {
		setLayout(null);
		
		//매장주문,포장주문 버튼 생성
		order1 = new JButton("매장 주문");
		order2 = new JButton("포장 주문");
		
		//매장주문 버튼
		order1.setFont(new Font("매장 주문", Font.BOLD, 10));
		order1.setBounds(80, 700, 300, 100);
		add(order1);
		
		//포장주문 버튼
		order2.setFont(new Font("포장 주문", Font.BOLD, 10));
		order2.setBounds(180, 700, 300, 100);
		add(order2);
		
		//매장주문,포장주문 버튼을 누르면 패널이 넘어가야한다.
		//해당 클래스에서 버튼 기능 설정하기
		
		//매장주문 버튼 기능추가
		order1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
	}
}
