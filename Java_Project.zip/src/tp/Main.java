package tp;

import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		PanelChange pch = new PanelChange();
		
		pch.setTitle("분식집 키오스크");
		
		pch.fm = new FirstMain(pch);
		pch.pp = new PassPanel(pch);
		
		
		pch.add(pch.fm);
		
		
		
		
		pch.setBounds(150, 150, 500, 700);
		pch.setResizable(false);
		pch.setVisible(true);
		pch.setDefaultCloseOperation(pch.EXIT_ON_CLOSE);
		

		
		

	}
}
