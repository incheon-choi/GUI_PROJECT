package tp;

import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class PassPanel extends JPanel {

	private PanelChange pch;
	JPanel pUp = new JPanel();
	JPanel MenuFirst = new JPanel();
	JPanel MenuSceond = new JPanel();
	JPanel MenuThird = new JPanel();
	JPanel pDown = new JPanel();
	
	
	JButton mf = new JButton("김    밥");
	JButton ms = new JButton("면    류");
	JButton mt = new JButton("식    사");
	
	
	int total = 0;
	String see ="";
	
public PassPanel(PanelChange pch) {
		
		// TODO Auto-generated constructor stub	
	
		this.pch = pch;	
		JLabel jlb = new JLabel();
		
		setLayout(null);
		

		
		

		
		//배열 정리 시작
		String food[] = { "야채김밥","참치김밥","치즈김밥","김치김밥"};
		int money[] = {2500,3500,3500,3500}; 
				
				
		String food2[] = {"우동","국수","냉모밀","물냉면"};
		int money2[] = {5000,5000,6000,6000}; 
				
				
		String food3[] = {"제육덮밥","오므라이스","순두부찌개","부대찌개"};
		int money3[] = {6000,6000,7000,7000};
				
				
		JButton ch[] = new JButton[food.length]; 
		JButton ch2[] = new JButton[food2.length]; 
		JButton ch3[] = new JButton[food3.length]; 
				
		TextField num[] = new TextField[food.length];
		TextField num2[] = new TextField[food2.length];
		TextField num3[] = new TextField[food3.length];
				
		Button plus[] =new Button[food.length];
		Button plus2[] =new Button[food2.length];
		Button plus3[] =new Button[food3.length];
				
		Button minus[] =new Button[food.length];
		Button minus2[] =new Button[food2.length];
		Button minus3[] =new Button[food3.length];
				
		JButton check[] = new JButton[food.length];
		JButton check2[] = new JButton[food2.length];
		JButton check3[] = new JButton[food3.length];
				
				
		Label lb[] = new Label[food.length];
		Label lb2[] = new Label[food2.length];
		Label lb3[] = new Label[food3.length];
				
				
		ImageIcon icon[] = new ImageIcon[food.length];
		ImageIcon icon2[] = new ImageIcon[food2.length];
		ImageIcon icon3[] = new ImageIcon[food3.length];
				
		//배열 정리 끝
				

		
		
		
		
		//상단 패널 조정.
		
		pUp.setBackground(new Color(102, 102, 153)); 
		pUp.setLayout(null);
		pUp.setBounds(0,0,500,450);
		
	
		//상단메뉴 패널 1
		
		

		mf.setFont(new Font("요리탭1", Font.BOLD, 11));
		mf.setFont(jlb.getFont().deriveFont(25.0f));
		mf.setBounds(20, 20, 100, 50);
		mf.setVisible(true);		
		
		

		MenuFirst.setBackground(new Color(255, 0, 0, 0));
		MenuFirst.setBounds(-140, 20, 500, 300);
		MenuFirst.setVisible(true);
		
		MenuFirst.add(mf);
		
		for(int i=0; i<food.length; i++) {
			
			//메뉴탭 버튼.
			ch[i] = new JButton(food[i]);
			if(i<2) {
				ch[i].setBounds(90 + i*200, 100, 95, 95);
				
			}else{
				ch[i].setBounds(90 + (i-2)*200, 250, 95, 95);
				
			}
			
			 icon[i] = new ImageIcon("D:\\web_cdy\\java_project\\java\\work\\Java_Project\\src\\image\\"+ i + ".png");
	         ch[i].setIcon(icon[i]);
			
			//txt 버튼
			
			num[i] = new TextField("0");
			num[i].setBackground(new Color(255, 204, 255));
			num[i].setEditable(false);
			num[i].setBounds(ch[i].getX() + 30, ch[i].getY() + 100, 30, 18);
			
			// - 버튼
			
			minus[i] = new Button("-");
			minus[i].setBounds(ch[i].getX() +10, num[i].getY(), 20 , 20);
			minus[i].setVisible(true);
			
			
			// + 버튼
			
			plus[i] = new Button("+");
			plus[i].setBounds(ch[i].getX() + 61, num[i].getY(), 20, 20);
			plus[i].setVisible(true);
			
			
			//가격
			
			lb[i] = new Label(money[i]+ "원");
			lb[i].setBounds(ch[i].getX() +20, num[i].getY() + 20, 80, 30);
			
			//체크
			check[i] = new JButton("확인");
			check[i].setBounds(ch[i].getX() + 85, num[i].getY(), 60, 20);
			check[i].setEnabled(false);
			
			
			//컴포넌트
			pUp.add(ch[i]);
			pUp.add(num[i]);
			pUp.add(minus[i]);
			pUp.add(plus[i]);
			pUp.add(lb[i]);
			pUp.add(check[i]);
		}
		
		
		mf.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				for(int i =0; i<food.length; i++) {
					ch[i].setVisible(true);
					num[i].setVisible(true);
					minus[i].setVisible(true);
					plus[i].setVisible(true);
					lb[i].setVisible(true);
					check[i].setVisible(true);
				}
				
				for(int i =0; i<food2.length; i++) {
					ch2[i].setVisible(false);
					num2[i].setVisible(false);
					minus2[i].setVisible(false);
					plus2[i].setVisible(false);
					lb2[i].setVisible(false);
					check2[i].setVisible(false);
				}
				
				for(int i =0; i<food3.length; i++) {
					ch3[i].setVisible(false);
					num3[i].setVisible(false);
					minus3[i].setVisible(false);
					plus3[i].setVisible(false);
					lb3[i].setVisible(false);
					check3[i].setVisible(false);
				}
				
				
			}
		});
		//상단 메뉴 패널 1종료.
		
		
		
		
		//상단 메뉴 패널 2
		
		
	
		ms.setFont(new Font("요리탭2", Font.BOLD, 11));
		ms.setFont(jlb.getFont().deriveFont(25.0f));
		ms.setBounds(20, 20, 100, 50);
		ms.setVisible(true);


		MenuSceond.setBackground(new Color(255, 0, 0, 0));
		MenuSceond.setBounds(0, 20, 500, 300);
		MenuSceond.setVisible(true);
		
		
		MenuSceond.add(ms);
		
		
		for(int i=0; i<food2.length; i++) {
			
			//메뉴탭 버튼.
			ch2[i] = new JButton(food2[i]);
			if(i<2) {
				ch2[i].setBounds(90 + i*200, 100, 95, 95);
				
			}else{
				ch2[i].setBounds(90 + (i-2)*200, 250, 95, 95);
				
			}
			
			 icon2[i] = new ImageIcon("D:\\web_cdy\\java_project\\java\\work\\Java_Project\\src\\image\\"+ i + "5.png");
	            ch2[i].setIcon(icon2[i]);
			//txt 버튼
			
			num2[i] = new TextField("0");
			num2[i].setBackground(new Color(255, 204, 255));
			num2[i].setEditable(false);
			num2[i].setBounds(ch2[i].getX() + 30, ch2[i].getY() + 100, 30, 18);
			
			// - 버튼
			
			minus2[i] = new Button("-");
			minus2[i].setBounds(ch2[i].getX() +10, num2[i].getY(), 20 , 20);
			minus2[i].setVisible(true);
			
			
			// + 버튼
			
			plus2[i] = new Button("+");
			plus2[i].setBounds(ch2[i].getX() + 61, num2[i].getY(), 20, 20);
			plus2[i].setVisible(true);
			
			
			//가격
			
			lb2[i] = new Label(money2[i]+ "원");
			lb2[i].setBounds(ch2[i].getX() +20, num2[i].getY() + 20, 80, 30);
			
			//체크
			check2[i] = new JButton("확인");
			check2[i].setBounds(ch2[i].getX() + 85, num2[i].getY(), 60, 20);
			check2[i].setEnabled(false);
			
			
			//컴포넌트
			pUp.add(ch2[i]);
			pUp.add(num2[i]);
			pUp.add(minus2[i]);
			pUp.add(plus2[i]);
			pUp.add(lb2[i]);
			pUp.add(check2[i]);
			
			}
		
		
		
		
		ms.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				for(int i =0; i<food.length; i++) {
					ch[i].setVisible(false);
					num[i].setVisible(false);
					minus[i].setVisible(false);
					plus[i].setVisible(false);
					lb[i].setVisible(false);
					check[i].setVisible(false);
				}
				
				for(int i =0; i<food2.length; i++) {
					ch2[i].setVisible(true);
					num2[i].setVisible(true);
					minus2[i].setVisible(true);
					plus2[i].setVisible(true);
					lb2[i].setVisible(true);
					check2[i].setVisible(true);
				}
				
				for(int i =0; i<food3.length; i++) {
					ch3[i].setVisible(false);
					num3[i].setVisible(false);
					minus3[i].setVisible(false);
					plus3[i].setVisible(false);
					lb3[i].setVisible(false);
					check3[i].setVisible(false);
				}

			}
		});
		
		
		
		
		
		//상단 메뉴 패널3
		
	
		
	
		mt.setFont(new Font("요리탭3", Font.BOLD, 11));
		mt.setFont(jlb.getFont().deriveFont(25.0f));
		mt.setBounds(20, 20, 100, 50);
		mt.setVisible(true);
		
		
		
		

		MenuThird.setBackground(new Color(255, 0, 0, 0));
		MenuThird.setBounds(140, 20, 500, 300);
		MenuThird.setVisible(true);
		
		MenuThird.add(mt);
		
		
		for(int i=0; i<food3.length; i++) {
			
			//메뉴탭 버튼.
			ch3[i] = new JButton(food3[i]);
			if(i<2) {
				ch3[i].setBounds(90 + i*200, 100, 95, 95);
				
			}else{
				ch3[i].setBounds(90 + (i-2)*200, 250, 95, 95);
				
			}
			
			 icon3[i] = new ImageIcon("D:\\web_cdy\\java_project\\java\\work\\Java_Project\\src\\image\\"+ i + "6.png");
	         ch3[i].setIcon(icon3[i]);
			//txt 버튼
			
			num3[i] = new TextField("0");
			num3[i].setBackground(new Color(255, 204, 255));
			num3[i].setEditable(false);
			num3[i].setBounds(ch3[i].getX() + 30, ch3[i].getY() + 100, 30, 18);
			
			// - 버튼
			
			minus3[i] = new Button("-");
			minus3[i].setBounds(ch3[i].getX() +10, num3[i].getY(), 20 , 20);
			minus3[i].setVisible(true);
			
			
			// + 버튼
			
			plus3[i] = new Button("+");
			plus3[i].setBounds(ch3[i].getX() + 61, num3[i].getY(), 20, 20);
			plus3[i].setVisible(true);
			
			
			//가격
			
			lb3[i] = new Label(money3[i]+ "원");
			lb3[i].setBounds(ch3[i].getX() +20, num3[i].getY() + 20, 80, 30);
			
			//체크
			check3[i] = new JButton("확인");
			check3[i].setBounds(ch3[i].getX() + 85, num3[i].getY(), 60, 20);
			check3[i].setEnabled(false);
			
			
			//컴포넌트
			pUp.add(ch3[i]);
			pUp.add(num3[i]);
			pUp.add(minus3[i]);
			pUp.add(plus3[i]);
			pUp.add(lb3[i]);
			pUp.add(check3[i]);

		}
		
		
		mt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				for(int i =0; i<food.length; i++) {
					ch[i].setVisible(false);
					num[i].setVisible(false);
					minus[i].setVisible(false);
					plus[i].setVisible(false);
					lb[i].setVisible(false);
					check[i].setVisible(false);

				}
				
				for(int i =0; i<food2.length; i++) {
					ch2[i].setVisible(false);
					num2[i].setVisible(false);
					minus2[i].setVisible(false);
					plus2[i].setVisible(false);
					lb2[i].setVisible(false);
					check2[i].setVisible(false);
				}
				
				for(int i =0; i<food3.length; i++) {
					ch3[i].setVisible(true);
					num3[i].setVisible(true);
					minus3[i].setVisible(true);
					plus3[i].setVisible(true);
					lb3[i].setVisible(true);
					check3[i].setVisible(true);
				}

				
				
			}
		});
		
		
		//장바구니 목록.
        TextArea ta = new TextArea("", 0, 0, TextArea.SCROLLBARS_VERTICAL_ONLY);
        ta.setText("\t 상품명 \t \t \t 가격 \t \t   수량 \t \t 합계\n\n");
        ta.setBackground(Color.white);
        ta.setEditable(false);
        ta.setBounds(0, 450, 480, 150);
        
		//아래쪽 버튼 패널.
        
		
		
		

		//취소 버튼.	
		JButton cancle = new JButton("취소 하기");
		
		
		cancle.setFont(new Font("취소 하기", Font.BOLD, 11));
		cancle.setFont(jlb.getFont().deriveFont(15.0f));
		cancle.setBounds(30, 600 ,100 ,50);
		cancle.setVisible(true);
		
		cancle.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "주문을 취소하고 초기화면으로 돌아갑니다.", "안내", JOptionPane.INFORMATION_MESSAGE);
				pch.change("fm");
				ta.setText("\t 상품명 \t \t \t 가격 \t \t   수량 \t \t 합계\n\n");
				//new FirstMain();
				//setVisible(false);
	
			}
		});
		
		
		//초기화 버튼
		
		JButton reset = new JButton("장바구니 비우기");
		reset.setFont(new Font("장바구니 비우기", Font.BOLD, 11));
		reset.setFont(jlb.getFont().deriveFont(15.0f));
		reset.setBounds(170, 600, 150, 50);
		reset.setVisible(true);
		
		
		reset.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				for(int i = 0; i<food.length; i++) {
					ch[i].setEnabled(true);
					plus[i].setEnabled(false);
					minus[i].setEnabled(false);
					num[i].setText("0");
					ta.setText("\t 상품명 \t \t \t 가격 \t \t   수량 \t \t 합계\n\n");
					
				}
				for(int i = 0; i<food2.length; i++) {
					ch2[i].setEnabled(true);
					plus2[i].setEnabled(false);
					minus2[i].setEnabled(false);
					num2[i].setText("0");
					ta.setText("\t 상품명 \t \t \t 가격 \t \t   수량 \t \t 합계\n\n");
				}
				
				for(int i = 0; i<food3.length; i++) {
					ch3[i].setEnabled(true);
					plus3[i].setEnabled(false);
					minus3[i].setEnabled(false);
					num3[i].setText("0");
					ta.setText("\t 상품명 \t \t \t 가격 \t \t   수량 \t \t 합계\n\n");
				
					
				}
				ta.setText("\t 상품명 \t \t \t 가격 \t \t   수량 \t \t 합계\n\n");
				
			}
		});
		
		
		//결제 버튼
		
		JButton result = new JButton("결제 하기");
		result.setFont(new Font("결제 하기", Font.BOLD, 11));
		result.setFont(jlb.getFont().deriveFont(15.0f));
		result.setBounds(355, 600, 100, 50);
		result.setVisible(true);
		
		result.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(null, ta.getText() + "결제가 완료되었습니다.", "안내", JOptionPane.INFORMATION_MESSAGE);
				
				for(int i = 0; i<food.length; i++) {
					ch[i].setEnabled(true);
					plus[i].setEnabled(false);
					minus[i].setEnabled(false);
					num[i].setText("0");
					ta.setText("\t 상품명 \t \t \t 가격 \t \t   수량 \t \t 합계\n\n");
					
				}
				for(int i = 0; i<food2.length; i++) {
					ch2[i].setEnabled(true);
					plus2[i].setEnabled(false);
					minus2[i].setEnabled(false);
					num2[i].setText("0");
					ta.setText("\t 상품명 \t \t \t 가격 \t \t   수량 \t \t 합계\n\n");
				}
				
				for(int i = 0; i<food3.length; i++) {
					ch3[i].setEnabled(true);
					plus3[i].setEnabled(false);
					minus3[i].setEnabled(false);
					num3[i].setText("0");
					ta.setText("\t 상품명 \t \t \t 가격 \t \t   수량 \t \t 합계\n\n");
					
				}
				
				
				
			}
		});
		
		//버튼 이벤트 정리.
		
		for(int i = 0; i< food.length; i++) {
			int j = i;
			
			//음식 아이콘 버튼.
			ch[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					plus[j].setEnabled(true);
					minus[j].setEnabled(true);
					ch[j].setEnabled(false);
					check[j].setEnabled(true);
					
					
					total =0;
					
				}
			});
		}
			for(int i = 0; i< food2.length; i++) {
				int j =i;
			ch2[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					plus2[j].setEnabled(true);
					minus2[j].setEnabled(true);
					ch2[j].setEnabled(false);
					check2[j].setEnabled(true);
					
					
					total =0;
					
				}
			});
			}
			
			for(int i = 0; i< food3.length; i++) {
				int j=i;
			
			ch3[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					plus3[j].setEnabled(true);
					minus3[j].setEnabled(true);
					ch3[j].setEnabled(false);
					check3[j].setEnabled(true);
					
					
					total =0;
					
				}
			});
			
			}
			
			
			
			
			
			//+ 버튼
			for(int i = 0; i< food.length; i++) {
				int j = i;
			plus[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					total = total +1;
					num[j].setText(total +"");
					check[j].setEnabled(true);
					if(total>0) {
						minus[j].setEnabled(true);
					}
					
					
				}
			});
			}
			
			for(int i = 0; i< food2.length; i++) {
				int j = i;
			
			plus2[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					total = total +1;
					num2[j].setText(total +"");
					check2[j].setEnabled(true);
					if(total>0) {
						minus2[j].setEnabled(true);
					}
					
					
				}
			});
			
			}
			
			for(int i = 0; i< food3.length; i++) {
				int j = i;
			plus3[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					total = total +1;
					num3[j].setText(total +"");
					check3[j].setEnabled(true);
					if(total>0) {
						minus3[j].setEnabled(true);
					}
					
					
				}
			});
			}
			
			for(int i = 0; i< food.length; i++) {
				int j = i;
			
			//-버튼
			minus[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					if(total>0) {
						total = total-1;
						num[j].setText(total + "");
						check[j].setEnabled(true);
						
					}else {
						minus[j].setEnabled(false);
					}
				}
			});
			}
			
			
			for(int i = 0; i< food2.length; i++) {
				int j = i;
			minus2[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					if(total>0) {
						total = total-1;
						num2[j].setText(total + "");
						check2[j].setEnabled(true);
						
					}else {
						minus2[j].setEnabled(false);
					}
				}
			});
			}
			
			
			
			for(int i = 0; i< food3.length; i++) {
				int j = i;
			
			minus3[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					if(total>0) {
						total = total-1;
						num3[j].setText(total + "");
						check3[j].setEnabled(true);
						
					}else {
						minus3[j].setEnabled(false);
					}
				}
			});
			}
			
			for(int i = 0; i< food.length; i++) {
				int j = i;
			
			//확인 버튼
			
			check[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
					see = ch[j].getActionCommand();
					ta.append("\t " + see + "\t \t" + money[j] + "\t \t    " + total + "\t \t"+money[j]*total+"원"+ "\n\n");
					
					check[j].setEnabled(false);
				}
			});
			}
			
			
			for(int i = 0; i< food2.length; i++) {
				int j = i;
			
			check2[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
					see = ch2[j].getActionCommand();
					ta.append("\t " + see + "\t \t \t" + money[j] + "\t\t  " + total + "\t \t"+money[j]*total+"원"+ "\n\n");
					
					check2[j].setEnabled(false);
				}
			});
			
			}
			
			
			for(int i = 0; i< food3.length; i++) {
				int j = i;
			check3[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
					see = ch3[j].getActionCommand();
					ta.append("\t " + see + "\t \t" + money[j] + "\t \t    " + total + "\t \t"+money[j]*total+"원"+ "\n\n");
					
					check3[j].setEnabled(false);
				}
			});
			
			}
		
		
		
		
		
		
		
		
		//	 컴포넌트
		//  백그라운드
		pUp.add(MenuFirst);
		pUp.add(MenuSceond);
		pUp.add(MenuThird);
		
		add(pUp);
		
		//중앙 장바구니
		add(ta);
		
		//하단 버튼들.
		add(cancle);
		add(reset);
		add(result);
		
		
		setBounds(150, 150, 500, 700);
		
		setVisible(true);
		
		
	}
}
