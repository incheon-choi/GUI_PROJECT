package bk;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import bk2.Panel01;
import tp.FirstMain;
import tp.PanelChange;
import shoping.Payment;

public class PanelSwitch extends JPanel {
	private PanelChange pch;
	private BasKetTest bk;
	private JButton Jbutton1;
	private JButton jbutton2;
	private JButton jbutton3;

	public static void main(String[] args) {

//	pch.setTitle("��ٱ���");
//	pch.Panel01 = new Panel01(pch);
//	
//	
//	pch.add(pch.Panel01);
//	
//	pch.setBounds(100, 100, 500, 700);
//	pch.setVisible(true);
//	pch.setDefaultCloseOperation(pch.EXIT_ON_CLOSE);
	}
}
