package mn;

import javax.swing.JFrame;

import mn2.Gimbap;

public class menuTest extends JFrame{
	public Gimbap gimbap = null;
	
	public  void change(String PanelName) {
		if(PanelName.equals("gimbap")) {
			getContentPane().removeAll();
			getContentPane().add(gimbap);
			revalidate();
			repaint();
		}
	}
	
}
