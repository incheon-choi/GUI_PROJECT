package mn;

import javax.swing.JButton;

import mn2.Gimbap;

public class menuMain {
	public static void main(String[] args) {
		menuTest mt = new menuTest();
		
		mt.setTitle("�޴�");
		mt.gimbap = new Gimbap(mt);
		
		
		
		mt.add(mt.gimbap);
		mt.setBounds(150, 150, 500, 700);
		mt.setVisible(true);
		mt.setDefaultCloseOperation(mt.EXIT_ON_CLOSE);

		
	}
}
