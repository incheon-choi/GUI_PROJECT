package mn2;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import mn.menuTest;

public class Gimbap extends JPanel {

	private menuTest mt;
	private JButton Jbutton1;
	private JButton Jbutton2;
	private JButton Jbutton3;
	private JButton Jbutton4;
	private JTextArea jTextArea1;
	private JScrollPane jscrollPane1;
	private JTextArea jTextArea2;
	private JScrollPane jscrollPane2;
	private JButton Jbutton5;
	private JButton Jbutton6;
	
	
	public Gimbap(menuTest mt) {
		this.mt = mt;
		setLayout(null);
		
		Jbutton1 = new JButton("���");
		Jbutton1.setBounds(20, 15, 100, 40);
		add(Jbutton1);
		
		Jbutton2 = new JButton("���");
		Jbutton2.setBounds(130, 15, 100, 40);
		add(Jbutton2);
		
		Jbutton3 = new JButton("�Ļ�");
		Jbutton3.setBounds(240, 15, 100, 40);
		add(Jbutton3);
		
		Jbutton4 = new JButton("����");
		Jbutton4.setBounds(350, 15, 100, 40);
		add(Jbutton4);
		
		jTextArea1 = new JTextArea();
		jscrollPane1 = new JScrollPane(jTextArea1);
		jscrollPane1.setBounds(10, 60, 465, 250);
		add(jscrollPane1);
		
		jTextArea2 = new JTextArea();
		jscrollPane2 = new JScrollPane(jTextArea2);
		jscrollPane2.setBounds(10, 320, 465, 250);
		add(jscrollPane2);
		
		Jbutton5 = new JButton("���");
		Jbutton5.setBounds(20, 580, 200, 70);
		add(Jbutton5);
		
		Jbutton6 = new JButton("����");
		Jbutton6.setBounds(265, 580, 200, 70);
		add(Jbutton6);
		
		
		
		
		
	}
	
	
	
	
	
	
}
