package menu;

import javax.swing.JFrame;
import menu.Gimbap;

public class MenuMain {
	public static void main(String[] args) {
//		JFrame f = new JFrame();
//		f.gimbap = new Gimbap(f);
//		Meal meal = new Meal();
//		Gimbap gim = new Gimbap();
//		//f.add(gimbap);
//		f.add(f.meal);
//		f.add(f.gim);
//
//
//
//
//
//
//
//
//
//		f.setBounds(150, 150, 500, 700);
//		f.setVisible(true);
//		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);

	}
}