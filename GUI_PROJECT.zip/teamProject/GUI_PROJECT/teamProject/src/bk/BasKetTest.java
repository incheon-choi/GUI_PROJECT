package bk;

import javax.swing.JFrame;

import bk2.Panel01;
import tp.PanelChange;

public class BasKetTest extends JFrame {
	public Panel01 Panel01 = null;
	


	public void change(String panelName) {
		if(panelName.equals("Panel01")) {
			getContentPane().removeAll();
			getContentPane().add(Panel01);
			revalidate();
			repaint();
		}
		
		
		
	}
}
