package menu;

public class Drink {
	
}
