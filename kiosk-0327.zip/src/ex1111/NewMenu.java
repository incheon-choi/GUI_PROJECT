package ex1111;

public class NewMenu {

}
