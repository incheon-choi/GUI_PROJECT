package tp;

import javax.swing.JFrame;

public class FirstMain {
public static void main(String[] args) {
		
		JFrame f = new JFrame("�н��� Ű����ũ");
		

		

		


		
		
		
		
		f.setBounds(100, 100, 500, 700);
		f.setVisible(true);
		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
		
		
		
	}
}
