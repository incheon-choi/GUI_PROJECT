package tp;

import javax.swing.JButton;
import javax.swing.JFrame;

public class FirstMain {

	public static void main(String[] args) {
		
		JFrame f = new JFrame("분식집 키오스크");
		

		
		
		
		
		
		
		f.setBounds(150, 150, 500, 700);
		f.setVisible(true);
		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
		
		
		
	}
	
}



/*
 * 구현해야 할 내용 : 
 * 
 *  1.초기 화면띄우기.
 *  
 *  2.초기 화면에 구현해야 하는버튼은 2개(매장주문/포장주문)
 * 	 
 *  3.메인화면에 무작위 이미지가 순차적으로 돌아가게 구현.
 *  
 *  4.입력이 없을 시 자동으로 초기화면으로 돌아갈 클래스 작성
 *  
 *  5.초기 사이즈는 500/700
 * 
 * 
 */




